CREATE TRIGGER [dbo].[DeleteNavigationItem] ON [dbo].[Navigation] FOR DELETE
AS

IF @@rowcount = 0 RETURN

DELETE FROM T
FROM Navigation AS T JOIN deleted AS D
  ON T.ParentId = D.Id
COMMIT



/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION

GO

