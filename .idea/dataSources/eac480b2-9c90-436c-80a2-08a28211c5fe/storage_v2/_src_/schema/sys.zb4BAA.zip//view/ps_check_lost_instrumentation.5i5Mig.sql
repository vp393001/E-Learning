CREATE VIEW ps_check_lost_instrumentation AS
  SELECT
    `information_schema`.`global_status`.`VARIABLE_NAME`  AS `variable_name`,
    `information_schema`.`global_status`.`VARIABLE_VALUE` AS `variable_value`
  FROM `information_schema`.`global_status`
  WHERE ((`information_schema`.`global_status`.`VARIABLE_NAME` LIKE 'perf%lost') AND
         (`information_schema`.`global_status`.`VARIABLE_VALUE` > 0));

